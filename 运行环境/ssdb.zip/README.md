ssdb-bin
========

SSDB pre-compiled executable binary for Windows.

# Installation and Setup

1. Download ssdb-server.exe and *.dll files from https://github.com/ideawu/ssdb-bin
2. Download ssdb.conf from https://github.com/ideawu/ssdb
3. Run cmd.exe from Start menu
4. Go into the folder where ssdb-server.exe resides in
5. Run ssdb-server.exe ssdb.conf
 
Now the ssdb-server is started on Windows, connect to it with PHP, Python, Java, etc...
